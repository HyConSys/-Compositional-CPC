#!/usr/bin/env julia
#=
Direct polynomial B,V/controller search, degree two, shared two-priority DPA.
Run ONLY through Conda environment optimization:
  julia Synthesis_Direct_CPC.jl [N=2] [seed=20261122] [candidate_budget=7] [normalized|physical]
  julia Synthesis_Direct_CPC.jl verify results.toml

Controller candidates are computed by admissibility/domain-invariance LPs;
acceptance requires a genuine B,V SOS feasibility solve and exact proof.
No Lyapunov decay, positive-definite certificate coefficient matrix, B=0,
Upsilon=0 or fixed relation between ranks is imposed. Each polynomial at each
automaton state has independent free coefficients. This incomplete outer
candidate search is not CEGIS and is not a global nonconvex optimizer.

The default CLI uses dimensionless closed-loop controller coordinates
(A11,A12,drift), mapped exactly back to the physical offset and gains.
The physical-coordinate candidate mode is retained for reproduction. Both
parameterizations have the same admissible controller polytope. Certificate
and SOS variable units are unchanged, as supported by the normalization study.

Numerical conditioning uses coordinates centered at the COMPUTED candidate's
fixed point, with all domains and target labels translated consistently. This
does not require stability of that point. Certificates are also exported in
the original physical coordinates. At an interior accepting stationary point,
the accepting self-transition residuals necessarily vanish. Their SOS faces
are reduced accordingly; this is an implied equality, not a stability test.

All affine SOS coefficient identities are repaired exactly over rationals;
every repaired Gram matrix, multiplier and original aggregate is then checked.
Raw solver coefficients and the correction magnitude are retained.
=#
include(joinpath(@__DIR__,"Synthesis_Buck_CPC.jl"))
using .BuckConverterCPC
using JuMP, LinearAlgebra, TOML, Dates, Printf, SHA
const CPC=BuckConverterCPC
const Rat=CPC.Exact
const PROCESS_START=time_ns()

struct Lin
    c::Rat
    a::Dict{Int,Rat}
end
Lin(x::Real)=Lin(Rat(x),Dict{Int,Rat}())
Base.zero(::Type{Lin})=Lin(0)
Base.zero(::Lin)=Lin(0)
Base.iszero(x::Lin)=iszero(x.c)&&isempty(x.a)
function Base.:+(x::Lin,y::Lin)
    a=copy(x.a)
    for (i,v) in y.a
        a[i]=get(a,i,CPC.rat(0))+v
        iszero(a[i])&&delete!(a,i)
    end
    Lin(x.c+y.c,a)
end
Base.:-(x::Lin)=Lin(-x.c,Dict(i=>-v for (i,v) in x.a))
Base.:-(x::Lin,y::Lin)=x+(-y)
Base.:+(x::Lin,y::Real)=x+Lin(y)
Base.:+(x::Real,y::Lin)=Lin(x)+y
Base.:-(x::Lin,y::Real)=x-Lin(y)
Base.:-(x::Real,y::Lin)=Lin(x)-y
Base.:*(s::Real,x::Lin)=iszero(s) ? Lin(0) : Lin(Rat(s)*x.c,Dict(i=>Rat(s)*v for (i,v) in x.a))
Base.:*(x::Lin,s::Real)=s*x
Base.:/(x::Lin,s::Real)=inv(Rat(s))*x
value_exact(x::Lin,u)=x.c+sum((v*u[i] for (i,v) in x.a);init=CPC.rat(0))

mutable struct ProofModel
    model::Model
    vars::Vector{VariableRef}
    ids::Dict{VariableRef,Int}
    names::Vector{String}
    nonnegative::Vector{Int}
    equations::Vector{Lin}
    blocks::Vector{NamedTuple}
    sos::Vector{NamedTuple}
    polynomials::Dict{String,Matrix{Lin}}
    supplies::Dict{String,Matrix{Lin}}
end
ProofModel()=ProofModel(CPC.make_model(:mosek),VariableRef[],Dict{VariableRef,Int}(),
    String[],Int[],Lin[],NamedTuple[],NamedTuple[],Dict(),Dict())
function register!(p,v)
    i=get!(p.ids,v) do
        push!(p.vars,v);push!(p.names,name(v));length(p.vars)
    end
    Lin(CPC.rat(0),Dict(i=>CPC.rat(1)))
end
function scalar!(p,name;nonnegative=false)
    v=@variable(p.model,base_name=name)
    nonnegative&&set_lower_bound(v,0.0)
    l=register!(p,v)
    nonnegative&&push!(p.nonnegative,only(keys(l.a)))
    l
end
function psd!(p,k,name)
    Q=@variable(p.model,[1:k,1:k],PSD,base_name=name)
    L=[register!(p,Q[i,j]) for i in 1:k,j in 1:k]
    ids=[only(keys(L[i,j].a)) for i in 1:k,j in 1:k]
    push!(p.blocks,(;name,ids))
    L
end
function jump_expression(p,l)
    a=AffExpr(Float64(l.c))
    for (i,v) in l.a
        add_to_expression!(a,Float64(v),p.vars[i])
    end
    a
end
function equation!(p,l)
    iszero(l)&&return
    @constraint(p.model,jump_expression(p,l)==0)
    push!(p.equations,l)
end
zero_lin(k)=[Lin(0) for _ in 1:k,_ in 1:k]
function free_polynomial!(p,k,name)
    H=zero_lin(k+1)
    for j in 1:k+1,i in 1:j
        v=scalar!(p,"$(name)_coef_$(i)_$(j)")
        H[i,j]=H[j,i]=i==j ? v : v/2
    end
    p.polynomials[name]=H
    H
end
function symmetric_supply!(p,k,name)
    H=zero_lin(k)
    for j in 1:k,i in 1:j
        H[i,j]=H[j,i]=scalar!(p,"$(name)_$(i)_$(j)")
    end
    p.supplies[name]=H
    H
end
function pullback(H,R)
    n=size(R,2); Q=zero_lin(n)
    for j in 1:n,i in 1:j
        z=Lin(0)
        for b in axes(R,1),a in axes(R,1)
            (iszero(R[a,i])||iszero(R[b,j])||iszero(H[a,b]))&&continue
            z=z+(R[a,i]*R[b,j])*H[a,b]
        end
        Q[i,j]=Q[j,i]=z
    end
    Q
end
function numeric_matrix(H,u)
    [value_exact(H[i,j],u) for i in axes(H,1),j in axes(H,2)]
end
function box_generator(k,i,lo,hi)
    Q=zeros(Rat,k+1,k+1)
    Q[1,1]=-lo*hi;Q[1,i+1]=Q[i+1,1]=(lo+hi)/2;Q[i+1,i+1]=-1
    Q
end
function target_generator(k,indices,center,radius;good=true)
    Q=zeros(Rat,k+1,k+1);Q[1,1]=radius^2-sum(abs2,center)
    for (i,e) in zip(indices,center)
        Q[1,i+1]=Q[i+1,1]=-e;Q[i+1,i+1]=-1
    end
    good ? Q : -Q
end
function sos!(p,residual,generators,name;stationary_face=false)
    k=size(residual,1)
    gram=if stationary_face
        @assert all(G[1,1]>0 for G in generators)
        Q=zero_lin(k);Q[2:end,2:end]=psd!(p,k-1,name*"_face_Gram");Q
    else
        psd!(p,k,name*"_Gram")
    end
    lambdas=Lin[]; remainder=copy(residual)
    if !stationary_face
        for (j,G) in enumerate(generators)
            l=scalar!(p,"$(name)_multiplier_$(j)";nonnegative=true)
            push!(lambdas,l)
            remainder=[remainder[a,b]-G[a,b]*l for a in 1:k,b in 1:k]
        end
    end
    for j in 1:k,i in 1:j
        equation!(p,remainder[i,j]-gram[i,j])
    end
    push!(p.sos,(;name,residual,generators,lambdas,gram,stationary_face))
end

"Controller candidate LP: ONLY input bounds and robust state-box preservation."
function controller_vertex(base,attempt)
    model=CPC.make_model(:mosek);N=base.N
    a=@variable(model,[1:N],lower_bound=0,upper_bound=1,base_name="duty_offset")
    ki=@variable(model,[1:N],base_name="ki")
    kv=@variable(model,[1:N],base_name="kv")
    for (n,p) in enumerate(base.modules)
        dt,L,C,E,r,G=Float64.((base.dt,p.L,p.C,p.source,p.r,p.G))
        si,sv=Float64.((base.current_scale,base.voltage_scale))
        degree=Float64(sum(base.conductance[n,:]))
        gainabs=@variable(model,[1:2],lower_bound=0,base_name="input_abs_$(n)")
        for (j,g) in enumerate((-si*ki[n]/E,sv*kv[n]/E))
            @constraint(model,gainabs[j]>=g);@constraint(model,gainabs[j]>=-g)
        end
        @constraint(model,a[n]>=sum(gainabs));@constraint(model,a[n]+sum(gainabs)<=1)
        F=[0.0 1-dt*(r+ki[n])/L dt*(kv[n]-1)*sv/(L*si);
           dt*degree/C dt*si/(C*sv) 1-dt*(G+degree)/C]
        c=dt*(E*a[n]-Float64(p.r*p.current_reference+base.voltage_reference))/(L*si)
        absolute=@variable(model,[1:2,1:4],lower_bound=0,base_name="next_abs_$(n)")
        for i in 1:2,j in 1:4
            z=j==1 ? (i==1 ? c : 0.0) : F[i,j-1]
            @constraint(model,absolute[i,j]>=z);@constraint(model,absolute[i,j]>=-z)
        end
        for i in 1:2
            @constraint(model,sum(absolute[i,j] for j in 1:4)<=1)
        end
    end
    # Different linear objectives explore the admissible controller polytope.
    if attempt==1
        @objective(model,Min,0.0)
    else
        coordinates=vcat(a,ki,kv);j=mod1((attempt-2)÷2+1,length(coordinates))
        direction=iseven(attempt) ? 1.0 : -1.0
        @objective(model,Min,direction*coordinates[j])
    end
    optimize!(model)
    termination_status(model) in (CPC.MOI.OPTIMAL,CPC.MOI.ALMOST_OPTIMAL)||error("controller LP: $(termination_status(model))")
    (;a=Rat.(value.(a)),ki=Rat.(value.(ki)),kv=Rat.(value.(kv)),status=string(termination_status(model)))
end

function controller_vertex_dimensionless(base,attempt)
    model=CPC.make_model(:mosek);N=base.N
    t=@variable(model,[1:N],base_name="closed_loop_A11")
    s=@variable(model,[1:N],base_name="closed_loop_A12")
    drift=@variable(model,[1:N],base_name="closed_loop_drift")
    a=Any[];ki=Any[];kv=Any[]
    for (n,p) in enumerate(base.modules)
        reference=(p.r*p.current_reference+base.voltage_reference)/p.source
        push!(a,Float64(reference)+Float64(p.L*base.current_scale/(base.dt*p.source))*drift[n])
        push!(ki,Float64(p.L/base.dt)*(1-t[n])-Float64(p.r))
        push!(kv,1+Float64(p.L*base.current_scale/(base.dt*base.voltage_scale))*s[n])
        @constraint(model,a[n]>=0);@constraint(model,a[n]<=1)
    end
    for (n,p) in enumerate(base.modules)
        dt,L,C,E,G=Float64.((base.dt,p.L,p.C,p.source,p.G))
        si,sv=Float64.((base.current_scale,base.voltage_scale))
        degree=Float64(sum(base.conductance[n,:]))
        gainabs=@variable(model,[1:2],lower_bound=0,base_name="input_abs_$(n)")
        for (j,g) in enumerate((-si*ki[n]/E,sv*kv[n]/E))
            @constraint(model,gainabs[j]>=g);@constraint(model,gainabs[j]>=-g)
        end
        @constraint(model,a[n]>=sum(gainabs));@constraint(model,a[n]+sum(gainabs)<=1)
        F=[0.0 t[n] s[n];dt*degree/C dt*si/(C*sv) 1-dt*(G+degree)/C]
        absolute=@variable(model,[1:2,1:4],lower_bound=0,base_name="next_abs_$(n)")
        for i in 1:2,j in 1:4
            z=j==1 ? (i==1 ? drift[n] : 0.0) : F[i,j-1]
            @constraint(model,absolute[i,j]>=z);@constraint(model,absolute[i,j]>=-z)
        end
        for i in 1:2
            @constraint(model,sum(absolute[i,j] for j in 1:4)<=1)
        end
    end
    if attempt==1
        @objective(model,Min,0.0)
    else
        physical=vcat(a,ki,kv);j=mod1((attempt-2)÷2+1,length(physical))
        direction=iseven(attempt) ? 1.0 : -1.0
        @objective(model,Min,direction*physical[j])
    end
    optimize!(model)
    termination_status(model) in (CPC.MOI.OPTIMAL,CPC.MOI.ALMOST_OPTIMAL)||error("controller LP: $(termination_status(model))")
    av=Rat[];kiv=Rat[];kvv=Rat[]
    for (n,p) in enumerate(base.modules)
        reference=(p.r*p.current_reference+base.voltage_reference)/p.source
        push!(av,reference+p.L*base.current_scale/(base.dt*p.source)*Rat(value(drift[n])))
        push!(kiv,p.L/base.dt*(1-Rat(value(t[n])))-p.r)
        push!(kvv,1+p.L*base.current_scale/(base.dt*base.voltage_scale)*Rat(value(s[n])))
    end
    (;a=av,ki=kiv,kv=kvv,status=string(termination_status(model)))
end

function controller_candidate(base,attempt;coordinates=:physical)
    coordinates in (:physical,:normalized)||error("controller coordinates must be physical or normalized")
    # Averaging admissible polytope vertices avoids crossover boundary errors.
    # This is a candidate-generation rule, not a stability/CPC restriction.
    vertices=[coordinates==:physical ? controller_vertex(base,k) :
              controller_vertex_dimensionless(base,k) for k in 1:1+6base.N]
    weights=fill(CPC.rat(1),length(vertices))
    attempt>1&&(weights[mod1(attempt-1,length(vertices))]+=attempt-1)
    total=sum(weights)
    a=[sum(weights[j]*vertices[j].a[n] for j in eachindex(vertices))/total for n in 1:base.N]
    ki=[sum(weights[j]*vertices[j].ki[n] for j in eachindex(vertices))/total for n in 1:base.N]
    kv=[sum(weights[j]*vertices[j].kv[n] for j in eachindex(vertices))/total for n in 1:base.N]
    (;a,ki,kv,status="computed polytope barycenter",LP_count=length(vertices))
end

function physical_data(base,theta)
    N=base.N;F=Matrix{Rat}[];c=Rat[]
    for (n,p) in enumerate(base.modules)
        dt=base.dt;degree=sum(base.conductance[n,:])
        f=Rat[0 1-dt*(p.r+theta.ki[n])/p.L dt*(theta.kv[n]-1)*base.voltage_scale/(p.L*base.current_scale);
              dt*degree/p.C dt*base.current_scale/(p.C*base.voltage_scale) 1-dt*(p.G+degree)/p.C]
        push!(F,f)
        append!(c,[dt*(p.source*theta.a[n]-p.r*p.current_reference-base.voltage_reference)/(p.L*base.current_scale),CPC.rat(0)])
        variation=(abs(theta.ki[n])*base.current_scale+abs(theta.kv[n])*base.voltage_scale)/p.source
        @assert theta.a[n]-variation>=0 && theta.a[n]+variation<=1 "controller input bound"
        for i in 1:2
            @assert sum(abs,f[i,:])+abs(c[2n-2+i])<=1 "controller state-box preservation"
        end
    end
    A=reduce(vcat,(F[n]*base.T[n] for n in 1:N))
    equilibrium=(Matrix{Rat}(I,2N,2N)-A)\c
    @assert A*equilibrium+c==equilibrium
    @assert all(abs.(equilibrium).<1)
    we=base.M*equilibrium
    # Independently evaluate the ORIGINAL physical scalar equations on an affine basis.
    for j in 0:2N
        z=zeros(Rat,2N);j>0&&(z[j]=1)
        next=zeros(Rat,2N)
        currents=[p.current_reference+base.current_scale*z[2n-1] for (n,p) in enumerate(base.modules)]
        voltages=[base.voltage_reference+base.voltage_scale*z[2n] for n in 1:N]
        for (n,p) in enumerate(base.modules)
            u=theta.a[n]+(-theta.ki[n]*base.current_scale*z[2n-1]+theta.kv[n]*base.voltage_scale*z[2n])/p.source
            ip=currents[n]+base.dt/p.L*(p.source*u-p.r*currents[n]-voltages[n])
            vp=voltages[n]+base.dt/p.C*(currents[n]-p.G*voltages[n]+
               sum(base.conductance[n,l]*(voltages[l]-voltages[n]) for l in 1:N))
            next[2n-1]=(ip-p.current_reference)/base.current_scale
            next[2n]=(vp-base.voltage_reference)/base.voltage_scale
        end
        @assert next==A*z+c "physical affine dynamics mismatch"
    end
    (;base,theta,F,c,A,equilibrium,we)
end

function aggregate!(p,modeldata,supplies,name)
    base=modeldata.base;m=2base.N;aggregate=zero_lin(m)
    for n in 1:base.N
        R=pullback(supplies[n],base.T[n])
        aggregate=[aggregate[i,j]+R[i,j] for i in 1:m,j in 1:m]
    end
    decomposition=CPC.composition_cliques(base);sumcones=zero_lin(m)
    for (j,C) in enumerate(decomposition.cliques)
        Z=psd!(p,length(C),"$(name)_clique_$(j)")
        for (a,i) in enumerate(C),(b,l) in enumerate(C)
            sumcones[i,l]=sumcones[i,l]+Z[a,b]
        end
    end
    for j in 1:m,i in 1:j
        equation!(p,aggregate[i,j]+sumcones[i,j])
    end
    aggregate
end

function progress_steps(base,allocation=nothing)
    steps=isnothing(allocation) ? fill(base.epsilon_local,base.N) : Rat.(allocation)
    length(steps)==base.N||throw(ArgumentError("one progress step per subsystem is required"))
    all(steps.>=0)||throw(ArgumentError("local progress steps must be nonnegative"))
    sum(steps)>0||throw(ArgumentError("the aggregate odd-priority progress must be positive"))
    steps
end

"Theorem 3 allocation: nonnegative local steps with positive aggregate progress."
function select_progress_allocation(d,policy::Symbol)
    policy==:uniform&&return nothing
    policy in (:allocated,:auto)||throw(ArgumentError("progress policy must be uniform, allocated, or auto"))
    distances=[sum(abs2,d.equilibrium[2n-1:2n]) for n in 1:d.base.N]
    policy==:auto&&all(v->v<d.base.radius^2,distances)&&return nothing
    eligible=findall(v->v<d.base.radius^2,distances)
    isempty(eligible)&&throw(ArgumentError("no strictly inside-target equilibrium for an allocated-progress candidate"))
    anchor=eligible[argmin(distances[eligible])]
    allocation=zeros(Rat,d.base.N)
    allocation[anchor]=d.base.N*d.base.epsilon_local
    allocation
end

function build_certificate(d,method;epsilon_allocation=nothing)
    p=ProofModel();base=d.base;N=base.N;m=2N;alpha=base.alpha
    steps=progress_steps(base,epsilon_allocation)
    if method==:monolithic
        B=[free_polynomial!(p,m,"B_$(q)") for q in ("bad","good")]
        V=[free_polynomial!(p,m,"V_$(q)") for q in ("bad","good")]
        boxes=[box_generator(m,i,-1-d.equilibrium[i],1-d.equilibrium[i]) for i in 1:m]
        initials=[box_generator(m,i,base.initial_lower[i]-d.equilibrium[i],base.initial_upper[i]-d.equilibrium[i]) for i in 1:m]
        sos!(p,-B[1],initials,"initial_bad")
        for q in 1:2
            sos!(p,V[q]+alpha*B[q],boxes,"nonnegative_$(q)")
        end
        transition=zeros(Rat,m+1,m+1);transition[1,1]=1;transition[2:end,2:end]=d.A
        good=[target_generator(m,[2n-1,2n],d.equilibrium[2n-1:2n],base.radius) for n in 1:N]
        cells=[(;name="good_branch_$(n)",next=2,gens=vcat(boxes,[good[n]])) for n in 1:N]
        push!(cells,(;name="bad",next=1,gens=vcat(boxes,[-g for g in good])))
        for q in 1:2,cell in cells
            residualB=alpha*B[q]-pullback(B[cell.next],transition)
            residualV=V[q]+alpha*B[q]-pullback(V[cell.next],transition)
            q==1&&(residualV[1,1]=residualV[1,1]-sum(steps))
            face=q==2&&cell.next==2&&all(g[1,1]>0 for g in cell.gens)
            sos!(p,residualB,cell.gens,"B_$(q)_$(cell.name)";stationary_face=face)
            sos!(p,residualV,cell.gens,"V_$(q)_$(cell.name)";stationary_face=face)
        end
    else
        Bs=[[free_polynomial!(p,2,"B_$(n)_$(q)") for q in ("bad","good")] for n in 1:N]
        Vs=[[free_polynomial!(p,2,"V_$(n)_$(q)") for q in ("bad","good")] for n in 1:N]
        Gammas=[symmetric_supply!(p,3,"Gamma_$(n)") for n in 1:N]
        Upsilons=[symmetric_supply!(p,3,"Upsilon_$(n)") for n in 1:N]
        H=Rat[1 0 0 0;0 0 1 0;0 0 0 1]
        for n in 1:N
            e=d.equilibrium[2n-1:2n];B=Bs[n];V=Vs[n]
            boxes=[box_generator(2,i,-1-e[i],1-e[i]) for i in 1:2]
            initials=[box_generator(2,i,base.initial_lower[2n-2+i]-e[i],base.initial_upper[2n-2+i]-e[i]) for i in 1:2]
            sos!(p,-B[1],initials,"initial_$(n)_bad")
            for q in 1:2
                sos!(p,V[q]+alpha*B[q],boxes,"nonnegative_$(n)_$(q)")
            end
            signalboxes=vcat([box_generator(3,1,-1-d.we[n],1-d.we[n])],
                         [box_generator(3,i+1,-1-e[i],1-e[i]) for i in 1:2])
            target=target_generator(3,[2,3],e,base.radius)
            transition=zeros(Rat,3,4);transition[1,1]=1;transition[2:end,2:end]=d.F[n]
            G=zero_lin(4);G[2:end,2:end]=Gammas[n]
            U=zero_lin(4);U[2:end,2:end]=Upsilons[n]
            for q in 1:2,good in (true,false),qn in (good ? (2,) : (1,2))
                gens=vcat(signalboxes,[good ? target : -target])
                rb=alpha*pullback(B[q],H)+U-pullback(B[qn],transition)
                rv=pullback(V[q]+alpha*B[q],H)+G-pullback(V[qn],transition)
                q==1&&(rv[1,1]=rv[1,1]-steps[n])
                # At a stationary self-transition with zero required decrease,
                # the barrier/rank pair forces B_q(0)=0. Both residuals vanish
                # there. This also applies at an odd state allocated step zero.
                zero_decrease=q==2||iszero(steps[n])
                face=q==qn&&zero_decrease&&all(g[1,1]>0 for g in gens)
                name="$(n)_$(q)_$(good ? "a" : "b")_$(qn)"
                sos!(p,rb,gens,"B_"*name;stationary_face=face)
                sos!(p,rv,gens,"V_"*name;stationary_face=face)
            end
        end
        aggregate!(p,d,Gammas,"Gamma")
        aggregate!(p,d,Upsilons,"Upsilon")
    end
    @objective(p.model,Min,0.0)
    p
end

"Sparse exact row echelon factorization of the coefficient identities."
function echelon(equations,priority)
    basis=Dict{Int,Lin}()
    for original in equations
        row=original
        while !isempty(row.a)
            pivot=argmin(i->priority[i],collect(keys(row.a)));v=row.a[pivot]
            if haskey(basis,pivot)
                row=row-v*basis[pivot]
            else
                basis[pivot]=row/v;break
            end
        end
        isempty(row.a)&&!iszero(row.c)&&error("inconsistent exact affine SOS identities")
    end
    basis
end
function proof_check(p,u;details=false)
    all(iszero(value_exact(e,u)) for e in p.equations)||return false
    all(u[i]>=0 for i in p.nonnegative)||return false
    for b in p.blocks
        Q=[u[i] for i in b.ids]
        CPC.exact_psd(Q).pass||return false
    end
    true
end
function aggregate_checks(p,d,u)
    checks=Dict{String,Any}()
    for family in ("Gamma","Upsilon")
        S=zeros(Rat,2d.base.N,2d.base.N)
        for n in 1:d.base.N
            G=numeric_matrix(p.supplies["$(family)_$(n)"],u)
            S+=d.base.T[n]'*G*d.base.T[n]
        end
        @assert CPC.exact_psd(-S).pass "original undecomposed $(family) aggregate"
        checks[family]=Dict("original_aggregate_exact"=>exactrows(S),
            "maximum_eigenvalue_diagnostic"=>eigmax(Symmetric(Float64.(S))),
            "exact_nonpositive"=>true)
    end
    checks
end
function repair(p,raw)
    # Reconstruct auxiliary Grams from the actual polynomial coefficients,
    # rather than solving ill-conditioned combinations for those coefficients.
    order=sort!(collect(eachindex(p.vars));by=i->
        (occursin("Gram",p.names[i])||occursin("clique",p.names[i]) ? 0 : 1,i))
    priority=zeros(Int,length(order))
    for (i,j) in enumerate(order)
        priority[j]=i
    end
    basis=echelon(p.equations,priority)
    pivots=sort!(collect(keys(basis));by=i->priority[i],rev=true)
    for bits in (32,42,52),threshold in (1e-9,1e-7,0.0)
        den=BigInt(2)^bits
        u=Rat[abs(v)<threshold ? CPC.rat(0) : round(BigInt,BigFloat(v)*den)//den for v in raw]
        for i in pivots
            row=basis[i]
            u[i]=-row.c-sum((v*u[j] for (j,v) in row.a if j!=i);init=CPC.rat(0))
        end
        if proof_check(p,u)
            return (;u,bits,threshold,rank=length(pivots),
                maximum_correction=maximum(abs.(Float64.(u)-raw)))
        end
    end
    error("Exact affine projection could not preserve all SOS cones")
end

fraction(x)=CPC.fraction(x)
exactrows(Q)=CPC.rows(fraction.(Q))
parseexact(s)=begin a,b=split(s,'/');parse(BigInt,a)//parse(BigInt,b) end
function polynomial_export(H,center,physical_origin,physical_scale)
    k=length(center);normalized=Matrix{Rat}(I,k+1,k+1);normalized[2:end,1]=-center
    original=permutedims(normalized)*H*normalized
    physical=zeros(Rat,k+1,k+1);physical[1,1]=1
    for i in 1:k
        physical[i+1,1]=-physical_origin[i]/physical_scale[i]
        physical[i+1,i+1]=1/physical_scale[i]
    end
    Dict("centered_coefficient_matrix_exact"=>exactrows(H),
         "original_normalized_coefficient_matrix_exact"=>exactrows(original),
         "original_physical_coefficient_matrix_exact"=>exactrows(physical'*original*physical),
         "centered_coefficient_matrix_decimal"=>CPC.rows(Float64.(H)))
end
function export_result(p,d,method,fix,raw;epsilon_allocation=nothing)
    base=d.base;u=fix.u
    steps=progress_steps(base,epsilon_allocation)
    polys=Dict{String,Any}()
    origins=reduce(vcat,([m.current_reference,base.voltage_reference] for m in base.modules))
    scales=repeat([base.current_scale,base.voltage_scale],base.N)
    for (name,H) in p.polynomials
        if method==:monolithic
            center=d.equilibrium;origin=origins;scale=scales
        else
            n=parse(Int,split(name,'_')[2]);idx=2n-1:2n
            center=d.equilibrium[idx];origin=origins[idx];scale=scales[idx]
        end
        polys[name]=polynomial_export(numeric_matrix(H,u),center,origin,scale)
    end
    witnesses=[Dict("name"=>s.name,"stationary_face"=>s.stationary_face,
        "residual_exact"=>exactrows(numeric_matrix(s.residual,u)),
        "Gram_exact"=>exactrows(numeric_matrix(s.gram,u)),
        "multipliers_exact"=>[fraction(value_exact(l,u)) for l in s.lambdas],
        "domain_generators_exact"=>exactrows.(s.generators)) for s in p.sos]
    result=Dict{String,Any}("method"=>string(method),"direct_BV_search"=>true,
        "degree"=>2,"alpha_exact"=>fraction(base.alpha),"epsilon_local_exact"=>fraction(base.epsilon_local),
        "epsilon_global_exact"=>fraction(sum(steps)),
        "unit_decrease_normalization"=>"Divide monolithic B,V, or the sums of local B,V, by epsilon_global.",
        "controller_offset_exact"=>fraction.(d.theta.a),"controller_ki_exact"=>fraction.(d.theta.ki),
        "controller_kv_exact"=>fraction.(d.theta.kv),"equilibrium_exact"=>fraction.(d.equilibrium),
        "A_original_normalized_exact"=>exactrows(d.A),"drift_original_normalized_exact"=>fraction.(d.c),
        "variable_names"=>p.names,"raw_solver_coefficients"=>raw,
        "repaired_exact_coefficients"=>fraction.(u),"coefficient_identity_count"=>length(p.equations),
        "SOS_condition_count"=>length(p.sos),"PSD_block_count"=>length(p.blocks),
        "maximum_coefficient_correction"=>fix.maximum_correction,
        "repair_rounding_bits"=>fix.bits,"repair_zero_threshold"=>fix.threshold,
        "repair_identity_rank"=>fix.rank,"polynomials"=>polys,"SOS_witnesses"=>witnesses,
        "original_aggregate_checks"=>method==:compositional ? aggregate_checks(p,d,u) : Dict{String,Any}(),
        "supplies_exact"=>Dict(name=>exactrows(numeric_matrix(H,u)) for (name,H) in p.supplies),
        "exact_proof_pass"=>true)
    if !isnothing(epsilon_allocation)
        delete!(result,"epsilon_local_exact")
        result["epsilon_reference_exact"]=fraction(base.epsilon_local)
        result["epsilon_allocation_exact"]=fraction.(steps)
        result["compositional_theorem"]="Theorem 3: nonnegative local allocation with positive aggregate"
    end
    result
end

function run_method(base,method,budget;controller_coordinates=:normalized)
    started=time_ns();history=Dict{String,Any}[]
    for attempt in 1:budget
        record=Dict{String,Any}("attempt"=>attempt);push!(history,record)
        try
            t=@elapsed theta=controller_candidate(base,attempt;coordinates=controller_coordinates)
            record["controller_LP_seconds"]=t
            record["controller_LP_count"]=theta.LP_count
            record["controller_offset_exact"]=fraction.(theta.a)
            record["controller_ki_exact"]=fraction.(theta.ki)
            record["controller_kv_exact"]=fraction.(theta.kv)
            t=@elapsed d=physical_data(base,theta)
            record["physical_model_seconds"]=t
            record["candidate_equilibrium_decimal"]=Float64.(d.equilibrium)
            println(method," attempt ",attempt,": solving free B,V SOS problem");flush(stdout)
            t=@elapsed p=build_certificate(d,method);record["SOS_build_seconds"]=t
            t=@elapsed optimize!(p.model);record["SOS_solve_seconds"]=t
            status=termination_status(p.model);record["SOS_status"]=string(status)
            has_values(p.model)||error("SOS solver returned $(status) without values")
            raw=value.(p.vars)
            record["raw_solver_coefficients"]=raw
            record["raw_minimum_Gram_eigenvalue"]=minimum(eigmin(Symmetric([raw[i] for i in b.ids])) for b in p.blocks)
            println(method," attempt ",attempt,": repairing and verifying exact SOS identities");flush(stdout)
            t=@elapsed fix=repair(p,raw);record["exact_repair_verification_seconds"]=t
            @assert proof_check(p,fix.u)
            # A changed coefficient must not pass the exact identity check.
            tampered=copy(fix.u);tampered[1]+=1
            @assert !proof_check(p,tampered)
            result=export_result(p,d,method,fix,raw)
            record["outcome"]="exact verified CPC and controller"
            result["attempts"]=history
            result["total_search_and_verification_seconds"]=(time_ns()-started)*1e-9
            return result
        catch err
            record["outcome"]="rejected";record["reason"]=sprint(showerror,err)
            record["elapsed_through_attempt_seconds"]=(time_ns()-started)*1e-9
            println(method," attempt ",attempt," rejected: ",record["reason"]);flush(stdout)
        end
    end
    Dict{String,Any}("method"=>string(method),"direct_BV_search"=>true,"exact_proof_pass"=>false,
        "attempts"=>history,"total_search_and_verification_seconds"=>(time_ns()-started)*1e-9)
end
function verify_saved(path)
    data=TOML.parsefile(path);base=CPC.generate_instance(data["N"],data["seed"])
    for method in (:monolithic,:compositional)
        r=data[string(method)];@assert r["exact_proof_pass"]
        theta=(;a=parseexact.(r["controller_offset_exact"]),ki=parseexact.(r["controller_ki_exact"]),kv=parseexact.(r["controller_kv_exact"]))
        allocation=haskey(r,"epsilon_allocation_exact") ? parseexact.(r["epsilon_allocation_exact"]) : nothing
        d=physical_data(base,theta);p=build_certificate(d,method;epsilon_allocation=allocation)
        @assert p.names==r["variable_names"]
        u=parseexact.(r["repaired_exact_coefficients"])
        @assert proof_check(p,u)
        @assert exactrows(d.A)==r["A_original_normalized_exact"]
        fix=(;u,bits=r["repair_rounding_bits"],threshold=r["repair_zero_threshold"],
              rank=r["repair_identity_rank"],maximum_correction=r["maximum_coefficient_correction"])
        expected=export_result(p,d,method,fix,r["raw_solver_coefficients"];epsilon_allocation=allocation)
        for key in ("polynomials","SOS_witnesses","supplies_exact","original_aggregate_checks")
            @assert expected[key]==r[key] "exported $(key) differs from its actual certificate"
        end
        println("Fresh reload ",method,": exact PASS; ",length(p.sos)," SOS obligations, ",length(p.equations)," coefficient identities")
    end
end
function main(args=ARGS)
    BLAS.set_num_threads(1)
    if !isempty(args)&&args[1]=="verify"
        verify_saved(args[2]);return
    end
    N=length(args)>=1 ? parse(Int,args[1]) : 2
    seed=length(args)>=2 ? parse(Int,args[2]) : 20261122
    budget=length(args)>=3 ? parse(Int,args[3]) : 7
    coordinates=length(args)>=4 ? Symbol(args[4]) : :normalized
    coordinates in (:normalized,:physical)||error("fourth argument must be normalized or physical")
    base=CPC.generate_instance(N,seed)
    println("Warming both direct CPC search paths on a separate N=2 parameter seed");flush(stdout)
    warm=CPC.generate_instance(2,20261121)
    warm_status=Dict{String,Any}()
    warm_seeds=Dict{String,Any}()
    for method in (:monolithic,:compositional)
        wr=run_method(warm,method,1;controller_coordinates=coordinates)
        warm_seeds[string(method)]=20261121
        if !wr["exact_proof_pass"]
            println("Completing ",method," warmup on the test plant; no solution values are reused");flush(stdout)
            wr=run_method(base,method,1;controller_coordinates=coordinates)
            warm_seeds[string(method)]=seed
        end
        warm_status[string(method)]=wr["exact_proof_pass"]
    end
    directory=joinpath(@__DIR__,"Results","Direct_CPC_N$(N)_"*Dates.format(now(UTC),"yyyymmddTHHMMSSsss")*"Z")
    mkpath(directory);path=joinpath(directory,"results.toml")
    result=Dict{String,Any}("N"=>N,"seed"=>seed,"candidate_budget"=>budget,
        "conda_environment"=>get(ENV,"CONDA_DEFAULT_ENV",""),"Julia_version"=>string(VERSION),
        "JuMP_version"=>string(pkgversion(JuMP)),"controller_search"=>"admissibility LP candidates, full B,V SOS oracle",
        "controller_coordinates"=>string(coordinates),
        "SOS_variable_units"=>"original; no certificate-unit scaling or additional robustness margin",
        "specification"=>"F G (a_1 OR ... OR a_N)","initial_automaton_state"=>"bad",
        "timing_scope"=>"all candidate LP construction/solves, physical reconstruction, B,V SOS assembly/solve, exact repair/checks and witness construction; excludes library loading, separate-seed warmup and file export",
        "warmup_exact_status"=>warm_status,"warmup_seed"=>20261121,
        "warmup_seed_by_method"=>warm_seeds,
        "source_sha256"=>bytes2hex(sha256(read(@__FILE__))))
    println("Direct free B,V search, N=",N,"; no stability decay constraints");flush(stdout)
    for method in (:monolithic,:compositional)
        result[string(method)]=run_method(base,method,budget;controller_coordinates=coordinates)
        open(path,"w") do io TOML.print(io,result;sorted=true) end
        println(method,": exact_proof_pass=",result[string(method)]["exact_proof_pass"]);flush(stdout)
    end
    cp(@__FILE__,joinpath(directory,"Synthesis_Direct_CPC.jl.txt"))
    cp(joinpath(@__DIR__,"Synthesis_Buck_CPC.jl"),joinpath(directory,"Synthesis_Buck_CPC.jl.txt"))
    println("Results: ",path);flush(stdout)
    all(result[string(m)]["exact_proof_pass"] for m in (:monolithic,:compositional))&&verify_saved(path)
end
abspath(PROGRAM_FILE)==abspath(@__FILE__)&&main()
