#!/usr/bin/env julia
# Isolated direct B,V/controller benchmark worker, always run in Conda optimization.
# work N method output_dir seed candidates solver_seconds [uniform|allocated|auto]
# verify result.toml output_dir
include(joinpath(@__DIR__,"Synthesis_Direct_CPC.jl"))

const BENCH_PHASES=("controller_search","physical_reconstruction","SOS_build",
                    "SOS_solve","exact_verification")
const BENCH_DIRECTORY=Ref("")
const BENCH_LEDGER=Ref(Dict{String,Any}())

function bench_write(path,data)
    mkpath(dirname(path))
    open(path*".tmp","w") do io TOML.print(io,data;sorted=true) end
    mv(path*".tmp",path;force=true)
end
function bench_checkpoint()
    bench_write(joinpath(BENCH_DIRECTORY[],"progress.toml"),BENCH_LEDGER[])
end
function bench_phase(f,phase)
    l=BENCH_LEDGER[];l["phase"]=phase;l["phase_started_unix"]=time()
    bench_checkpoint();started=time_ns()
    try
        f()
    finally
        elapsed=(time_ns()-started)*1e-9
        if get(l,"timed_search",false)
            l["phase_seconds"][phase]=get(l["phase_seconds"],phase,0.0)+elapsed
            if !isempty(l["attempts"])
                r=last(l["attempts"])
                r["phase_seconds"][phase]=get(r["phase_seconds"],phase,0.0)+elapsed
            end
        end
        l["last_phase"]=phase
        l["phase"]="between_stages";l["phase_started_unix"]=time()
        bench_checkpoint()
    end
end
function bench_plant(base)
    # Deliberately exclude the legacy supplied gains, unused by this search.
    physical=[(p.L,p.C,p.r,p.G,p.source,p.current_reference) for p in base.modules]
    bytes2hex(sha256(string(base.N,base.seed,physical,base.conductance,base.M,
        base.dt,base.current_scale,base.voltage_scale,base.voltage_reference,
        base.radius,base.alpha,base.epsilon_local,base.initial_lower,base.initial_upper)))
end
function bench_stop(status,reason;code=2)
    l=BENCH_LEDGER[];l["status"]=status;l["reason"]=reason
    if status in ("TIMEOUT","MEMORY_LIMIT")
        l["resource_stage"]=get(l,"last_phase","startup")
    end
    l["timed_search"]=false;l["finished_unix"]=time()
    l["phase"]="finished";bench_checkpoint()
    bench_write(joinpath(BENCH_DIRECTORY[],"outcome.toml"),l)
    println(status,": ",reason);flush(stdout)
    code
end
function bench_reject!(r,reason,started)
    r["outcome"]="rejected";r["reason"]=reason
    r["elapsed_seconds"]=(time_ns()-started)*1e-9
    bench_checkpoint()
end
function bench_verify_one(path)
    saved=TOML.parsefile(path);r=saved["result"];method=Symbol(saved["method"])
    base=CPC.generate_instance(saved["N"],saved["seed"])
    @assert bench_plant(base)==saved["plant_sha256"] "plant fingerprint mismatch"
    theta=(;a=parseexact.(r["controller_offset_exact"]),
        ki=parseexact.(r["controller_ki_exact"]),kv=parseexact.(r["controller_kv_exact"]))
    allocation=haskey(r,"epsilon_allocation_exact") ? parseexact.(r["epsilon_allocation_exact"]) : nothing
    d=physical_data(base,theta);p=build_certificate(d,method;epsilon_allocation=allocation)
    @assert p.names==r["variable_names"]
    u=parseexact.(r["repaired_exact_coefficients"])
    @assert proof_check(p,u) "fresh exact proof failed"
    @assert exactrows(d.A)==r["A_original_normalized_exact"]
    fix=(;u,bits=r["repair_rounding_bits"],threshold=r["repair_zero_threshold"],
          rank=r["repair_identity_rank"],maximum_correction=r["maximum_coefficient_correction"])
    expected=export_result(p,d,method,fix,r["raw_solver_coefficients"];epsilon_allocation=allocation)
    for key in ("polynomials","SOS_witnesses","supplies_exact","original_aggregate_checks")
        @assert expected[key]==r[key] "exported $key differs from exact solution"
    end
    true
end
function bench_work(N,method,seed,budget,solver_seconds;progress_policy=:uniform)
    l=BENCH_LEDGER[];base=CPC.generate_instance(N,seed)
    l["plant_sha256"]=bench_plant(base)
    l["controller_coordinates"]="normalized";l["SOS_variable_units"]="original"
    l["progress_policy"]=string(progress_policy)
    l["backend"]=method==:compositional ? "MOSEK exact aggregate clique lift" : "MOSEK dense monolithic SOS"
    l["solver_LP_limit_seconds"]=120.0
    l["solver_SOS_limit_seconds"]=solver_seconds
    l["Julia_version"]=string(VERSION);l["JuMP_version"]=string(pkgversion(JuMP))
    l["MosekTools_version"]=string(pkgversion(CPC.MosekTools))
    l["MOSEK_version"]=string(CPC.MosekTools.Mosek.getversion())
    l["warmup_seed"]=20261121
    bench_phase("warmup") do
        warm=run_method(CPC.generate_instance(2,20261121),method,1;controller_coordinates=:normalized)
        @assert warm["exact_proof_pass"] "independent warmup did not produce an exact certificate"
    end
    GC.gc()
    l["phase_seconds"]=Dict{String,Any}(k=>0.0 for k in BENCH_PHASES)
    l["timed_search"]=true;l["search_started_unix"]=time()
    search_started=time_ns()
    for attempt in 1:budget
        attempt_started=time_ns()
        r=Dict{String,Any}("attempt"=>attempt,"outcome"=>"running",
            "phase_seconds"=>Dict{String,Any}())
        push!(l["attempts"],r);bench_checkpoint()
        theta=bench_phase("controller_search") do
            controller_candidate(base,attempt;coordinates=:normalized)
        end
        r["controller_LP_count"]=theta.LP_count
        r["controller_offset_exact"]=fraction.(theta.a)
        r["controller_ki_exact"]=fraction.(theta.ki)
        r["controller_kv_exact"]=fraction.(theta.kv)
        d=try
            bench_phase("physical_reconstruction") do
                physical_data(base,theta)
            end
        catch err
            if err isa LinearAlgebra.SingularException
                bench_reject!(r,"unsupported singular coordinate translation",attempt_started)
                continue
            end
            rethrow()
        end
        allocation=try
            select_progress_allocation(d,progress_policy)
        catch err
            if err isa ArgumentError&&occursin("no strictly inside-target equilibrium",sprint(showerror,err))
                bench_reject!(r,sprint(showerror,err),attempt_started);continue
            end
            rethrow()
        end
        if !isnothing(allocation)
            r["epsilon_allocation_exact"]=fraction.(allocation)
            r["progress_anchor"]=findfirst(>(0),allocation)
            r["theorem"]="Theorem 3 allocated progress"
        end
        r["resolved_progress_policy"]=isnothing(allocation) ? "uniform" : "allocated"
        p=bench_phase("SOS_build") do
            build_certificate(d,method;epsilon_allocation=allocation)
        end
        set_optimizer_attribute(p.model,"MSK_DPAR_OPTIMIZER_MAX_TIME",solver_seconds)
        l["scalar_variables"]=length(p.vars);l["SOS_conditions"]=length(p.sos)
        l["coefficient_identities"]=length(p.equations)
        l["PSD_block_orders"]=[size(b.ids,1) for b in p.blocks]
        if method==:compositional
            @assert any(occursin("Gamma_clique",b.name) for b in p.blocks)
            @assert any(occursin("Upsilon_clique",b.name) for b in p.blocks)
        end
        bench_phase("SOS_solve") do
            optimize!(p.model)
        end
        status=string(termination_status(p.model));r["solver_status"]=status
        l["solver_status"]=status
        if status in ("TIME_LIMIT","MEMORY_LIMIT")
            r["outcome"]="resource_limit";r["elapsed_seconds"]=(time_ns()-attempt_started)*1e-9
            l["search_elapsed_seconds"]=(time_ns()-search_started)*1e-9
            return bench_stop(status=="TIME_LIMIT" ? "TIMEOUT" : "MEMORY_LIMIT","SOS returned $status")
        end
        if status in ("INFEASIBLE","ALMOST_INFEASIBLE","INFEASIBLE_OR_UNBOUNDED",
                      "LOCALLY_INFEASIBLE","ITERATION_LIMIT","SLOW_PROGRESS")
            bench_reject!(r,"SOS returned $status",attempt_started);continue
        end
        status in ("OPTIMAL","ALMOST_OPTIMAL")||error("Unexpected SOS solver status $status")
        @assert has_values(p.model) "successful status without primal values"
        raw=value.(p.vars)
        result=try
            bench_phase("exact_verification") do
                fix=repair(p,raw)
                @assert proof_check(p,fix.u)
                tampered=copy(fix.u);tampered[1]+=1
                @assert !proof_check(p,tampered) "tampering was not detected"
                # Includes original aggregate checks and exact physical-coordinate
                # pullbacks/proof-witness construction, but excludes file writing.
                export_result(p,d,method,fix,raw;epsilon_allocation=allocation)
            end
        catch err
            if sprint(showerror,err)=="Exact affine projection could not preserve all SOS cones"
                bench_reject!(r,"numerical candidate did not admit exact cone-preserving repair",attempt_started)
                continue
            end
            rethrow()
        end
        r["outcome"]="accepted";r["elapsed_seconds"]=(time_ns()-attempt_started)*1e-9
        l["search_elapsed_seconds"]=(time_ns()-search_started)*1e-9
        l["timed_search"]=false;l["exact_proof_pass"]=true
        saved=Dict{String,Any}("N"=>N,"seed"=>seed,"method"=>string(method),
            "plant_sha256"=>l["plant_sha256"],"result"=>result,
            "controller_coordinates"=>"normalized","backend"=>l["backend"],
            "specification"=>"F G (a_1 OR ... OR a_N)","progress_policy"=>string(progress_policy))
        bench_phase("file_export") do
            bench_write(joinpath(BENCH_DIRECTORY[],"result.toml"),saved)
        end
        return bench_stop("CERTIFIED","$status with exact proof";code=0)
    end
    l["search_elapsed_seconds"]=(time_ns()-search_started)*1e-9
    bench_stop("NO_CERTIFICATE","candidate budget exhausted; no nonexistence claim";code=2)
end
function benchmark_main(args=ARGS)
    mode=args[1]
    directory=mode=="verify" ? args[3] : args[4]
    BENCH_DIRECTORY[]=directory;mkpath(directory)
    BENCH_LEDGER[]=Dict{String,Any}("mode"=>mode,"status"=>"RUNNING",
        "phase"=>"startup","phase_started_unix"=>time(),"timed_search"=>false,
        "phase_seconds"=>Dict{String,Any}(),"attempts"=>Dict{String,Any}[],
        "conda_environment"=>get(ENV,"CONDA_DEFAULT_ENV",""))
    @assert get(ENV,"CONDA_DEFAULT_ENV","")=="optimization" "use Conda optimization"
    BLAS.set_num_threads(1)
    try
        if mode=="verify"
            t=@elapsed bench_phase("reload_verification") do
                bench_verify_one(args[2])
            end
            BENCH_LEDGER[]["reload_verification_seconds"]=t
            BENCH_LEDGER[]["exact_proof_pass"]=true
            return bench_stop("VERIFIED","fresh-process reload passed";code=0)
        end
        @assert mode=="work"
        N=parse(Int,args[2]);method=Symbol(args[3])
        @assert method in (:monolithic,:compositional)
        BENCH_LEDGER[]["N"]=N;BENCH_LEDGER[]["method"]=string(method)
        policy=length(args)>=8 ? Symbol(args[8]) : :uniform
        @assert policy in (:uniform,:allocated,:auto)
        bench_work(N,method,parse(Int,args[5]),parse(Int,args[6]),parse(Float64,args[7]);progress_policy=policy)
    catch err
        showerror(stderr,err,catch_backtrace());println(stderr)
        message=sprint(showerror,err)
        if err isa OutOfMemoryError
            return bench_stop("MEMORY_LIMIT",message)
        elseif startswith(message,"controller LP: TIME_LIMIT")
            return bench_stop("TIMEOUT",message)
        elseif startswith(message,"controller LP: MEMORY_LIMIT")
            return bench_stop("MEMORY_LIMIT",message)
        elseif startswith(message,"controller LP: INFEASIBLE")
            return bench_stop("NO_CERTIFICATE",message)
        end
        bench_stop("FATAL",message;code=3)
    end
end
abspath(PROGRAM_FILE)==abspath(@__FILE__)&&exit(benchmark_main())
