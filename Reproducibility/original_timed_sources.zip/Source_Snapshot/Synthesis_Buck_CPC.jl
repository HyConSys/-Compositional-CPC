#!/usr/bin/env julia
"""
Shared-global-DPA buck-converter CPC pilot (default: N = 2).

Run every Julia invocation through the optimization Conda environment:
    conda run -n optimization julia Code/Buck_CPC/Synthesis_Buck_CPC.jl 2 mosek
On hosts with the Julia 1.10/libopenlibm executable-stack compatibility issue:
    conda run -n optimization env GLIBC_TUNABLES=glibc.rtld.execstack=2 \
        julia --startup-file=no Code/Buck_CPC/Synthesis_Buck_CPC.jl 2 mosek

Arguments: N [mosek|clarabel] [seed] [samples], or: verify saved/results.toml.
MOSEK is the default; Clarabel is an independently tested alternative.
Both formulations always use the explicitly selected, same SDP solver.

Plant: forward-Euler discretization of averaged buck converters connected by
resistive lines. This is the defined discrete-time benchmark; no guarantee is
claimed for switching ripple, line inductance, or continuous intersample motion.
Each module has distinct L, C, r, G, source voltage and supplied affine feedback.
Both methods compute certificates for that SAME fixed feedback, not controllers.

Specification: F G (a_1 OR ... OR a_N), where a_n means the normalized current
and voltage errors lie in a disk. It does NOT mean every converter is regulated
or that one converter necessarily meets an entire network's power demand.
There is ONE shared global automaton state q, with priorities bad=1, good=2.
The exact local projections are a_n -> {good}, b_n -> {bad, good}.

Degree-two template, in both formulations:
    B = 0, Upsilon = 0, V_good(z) = z' P z, V_bad(z) = z' P z + epsilon.
P is searched, not supplied. The compositional model searches a DIFFERENT P_n
and common-across-q Gamma_n for EACH module; the monolithic model searches a
dense global P. Both use the same fixed constant SOS multiplier lambda and the
same trace normalization. This is a structured quadratic-SOS pilot, not a full
unrestricted polynomial/barrier or controller search.

All quadratic SOS conditions are represented explicitly by PSD Gram matrices
in JuMP. No TSSOS sparsity heuristic or unnecessary higher SOS order is used.
The outputs include the full binary64 coefficients and exact rational
diagonal-dominance or LDL' checks reconstructed from those coefficients and the exact model.
No separate analytic certificate is substituted for a numerical solver output.
"""
module BuckConverterCPC

using JuMP
using Clarabel
using MosekTools
using LinearAlgebra
using SparseArrays
using Random
using Printf
using TOML
using Dates
using Test

const MOI = JuMP.MOI
const Exact = Rational{BigInt}
rat(n::Integer, d::Integer=1) = BigInt(n) // BigInt(d)
exact_matrix(A) = Exact.(A)  # Float64 -> exact binary rational, not decimal rounding.
rows(A) = [collect(row) for row in eachrow(A)]
fraction(x::Exact) = string(numerator(x), "/", denominator(x))

function generate_instance(N::Int=2, seed::Int=20261122)
    N >= 2 || throw(ArgumentError("N must be at least 2"))
    rng = MersenneTwister(seed)
    dt, current_scale, voltage_scale = rat(1, 20_000), rat(1, 10), rat(1)
    voltage_reference = rat(24)
    radius, epsilon_local, alpha = rat(7, 20), rat(1, 1000), rat(1, 100)
    lambda = epsilon_local / radius^2
    modules = NamedTuple[]
    for n in 1:N
        L = rat(rand(rng, 80:120), 100_000) # H
        C = rat(rand(rng, 80:120), 1_000_000) # F
        r = rat(rand(rng, 8:16), 100) # Ohm
        G = rat(rand(rng, 16:24), 100) # Siemens
        source = rat(rand(rng, 46:54)) # V
        ki = rat(rand(rng, 350:450), 100) # Ohm (supplied feedback gain)
        kv = rat(rand(rng, 85:95), 100)
        current_reference = G * voltage_reference
        duty_reference = (voltage_reference + r * current_reference) / source
        push!(modules, (; n, L, C, r, G, source, ki, kv,
                         current_reference, duty_reference))
    end

    # Simple undirected cycle: N=2 has ONE physical line, not two copies of it.
    edges = sort!(collect(Set(minmax(n, mod1(n + 1, N)) for n in 1:N)))
    conductance = zeros(Exact, N, N)
    for (i, j) in edges
        conductance[i, j] = conductance[j, i] = rat(rand(rng, 5:15), 1000)
    end
    M = zeros(Exact, N, 2N)
    F, T = Matrix{Exact}[], Matrix{Exact}[]
    for (n, p) in enumerate(modules)
        degree = sum(conductance[n, :])
        degree > 0 || error("isolated module")
        # w_n is a conductance-weighted average of neighbors' normalized
        # voltage errors, so W_n=[-1,1]. The full shifted output is z_n in R^2.
        for j in 1:N
            M[n, 2j] = conductance[n, j] / degree
        end
        A = Exact[
            1-dt*(p.r+p.ki)/p.L   dt*(p.kv-1)*voltage_scale/(p.L*current_scale);
            dt*current_scale/(p.C*voltage_scale)  1-dt*(p.G+degree)/p.C
        ]
        b = Exact[0, dt * degree / p.C]
        push!(F, hcat(b, A)) # local signal order: [w_n,z_{n,1},z_{n,2}]
        Tn = zeros(Exact, 3, 2N)
        Tn[1, :] = M[n, :]
        Tn[2, 2n-1], Tn[3, 2n] = 1, 1
        push!(T, Tn)
    end
    A = reduce(vcat, (F[n] * T[n] for n in 1:N))
    initial_lower = repeat(Exact[rat(-9, 10), rat(3, 5)], N)
    initial_upper = repeat(Exact[rat(-7, 10), rat(4, 5)], N)
    return (; N, seed, dt, current_scale, voltage_scale, voltage_reference,
             radius, epsilon_local, alpha, lambda, modules, conductance, M, F, T, A,
             initial_lower, initial_upper)
end

function physical_controller(instance, n, z)
    p = instance.modules[n]
    di, dv = instance.current_scale * z[1], instance.voltage_scale * z[2]
    return p.duty_reference + (-p.ki * di + p.kv * dv) / p.source
end

function physical_next(instance, z)
    N = instance.N
    currents = [p.current_reference + instance.current_scale * z[2n-1]
                for (n, p) in enumerate(instance.modules)]
    voltages = [instance.voltage_reference + instance.voltage_scale * z[2n]
                for n in 1:N]
    next = similar(z)
    for (n, p) in enumerate(instance.modules)
        u = physical_controller(instance, n, z[2n-1:2n])
        line_current = sum(instance.conductance[n, j] * (voltages[j] - voltages[n])
                           for j in 1:N)
        ip = currents[n] + instance.dt / p.L *
             (p.source * u - p.r * currents[n] - voltages[n])
        vp = voltages[n] + instance.dt / p.C *
             (currents[n] - p.G * voltages[n] + line_current)
        next[2n-1] = (ip - p.current_reference) / instance.current_scale
        next[2n] = (vp - instance.voltage_reference) / instance.voltage_scale
    end
    return next
end

available(instance, z_n) = sum(abs2, z_n) <= instance.radius^2
global_successor(instance, z) =
    any(available(instance, z[2n-1:2n]) for n in 1:instance.N) ? :good : :bad
local_successors(is_available::Bool) = is_available ? (:good,) : (:bad, :good)
priority(q::Symbol) = q == :bad ? 1 : q == :good ? 2 : error("unknown DPA state")

function validate_instance(instance)
    N = instance.N
    @testset "Buck model, domains, feedback, and shared DPA" begin
        replay = generate_instance(N, instance.seed)
        @test replay.modules == instance.modules
        @test replay.A == instance.A && replay.M == instance.M
        @test length(unique([(p.L, p.C, p.r, p.G, p.source, p.ki, p.kv)
                             for p in instance.modules])) == N
        @test length(unique([Tuple(vec(Fn)) for Fn in instance.F])) == N
        @test size(instance.M) == (N, 2N)
        @test size(instance.A) == (2N, 2N)
        for n in 1:N
            @test sum(abs, instance.M[n, :]) == 1
            @test size(instance.F[n]) == (2, 3)
            @test instance.A[2n-1:2n, :] == instance.F[n] * instance.T[n]
            # Exact robust preservation of the entire X_n=[-1,1]^2 for
            # EVERY w_n in W_n=[-1,1], not just for simulated neighbors.
            @test all(sum(abs, instance.F[n][i, :]) < 1 for i in 1:2)
            p = instance.modules[n]
            variation = (p.ki * instance.current_scale +
                         p.kv * instance.voltage_scale) / p.source
            @test p.duty_reference - variation >= 0
            @test p.duty_reference + variation <= 1
        end
        @test physical_next(instance, zeros(Exact, 2N)) == zeros(Exact, 2N)
        z = Exact[rat((-1)^j * j, 2N+1) for j in 1:2N]
        @test physical_next(instance, z) == instance.A * z
        @test global_successor(instance, zeros(Exact, 2N)) == :good
        @test global_successor(instance, ones(Exact, 2N)) == :bad
        mixed = ones(Exact, 2N)
        mixed[1:2] .= 0
        @test global_successor(instance, mixed) == :good # OR, not AND.

        # Exhaustive letter-level containment, independent of any trajectory.
        for mask in 0:(2^min(N, 10)-1)
            flags = [Bool((mask >> (n-1)) & 1) for n in 1:min(N, 10)]
            N > 10 && append!(flags, falses(N-10))
            qp = any(flags) ? :good : :bad
            for q in (:bad, :good), n in 1:N
                @test qp in local_successors(flags[n])
                @test priority(q) == (q == :bad ? 1 : 2)
            end
        end
    end
    rho = maximum(sum(abs, instance.A[i, :]) for i in 1:2N)
    @assert rho < 1
    # Exact, deterministic entry bound for the WHOLE initial box. Once in
    # this smaller cube, contraction keeps every module in its target disk.
    bound = maximum(max.(abs.(instance.initial_lower), abs.(instance.initial_upper)))
    entry = 0
    while 2bound^2 > instance.radius^2
        bound *= rho
        entry += 1
        entry <= 10_000 || error("entry bound exceeded pilot limit")
    end
    return (; rho, guaranteed_available_step=entry,
             guaranteed_good_automaton_step=entry+1)
end

function make_model(solver::Symbol; tolerance=1.0e-9, solver_chordal=true, verbose=false)
    if solver == :clarabel
        model = Model(Clarabel.Optimizer)
        set_optimizer_attribute(model, "tol_feas", tolerance)
        set_optimizer_attribute(model, "tol_gap_abs", tolerance)
        set_optimizer_attribute(model, "tol_gap_rel", tolerance)
        set_optimizer_attribute(model, "max_iter", 250)
        set_optimizer_attribute(model, "time_limit", 120.0)
        set_optimizer_attribute(model, "max_threads", 1)
        set_optimizer_attribute(model, "chordal_decomposition_enable", solver_chordal)
    elseif solver == :mosek
        model = Model(MosekTools.Optimizer)
        set_optimizer_attribute(model, "MSK_IPAR_NUM_THREADS", 1)
        set_optimizer_attribute(model, "MSK_DPAR_OPTIMIZER_MAX_TIME", 120.0)
        for key in ("MSK_DPAR_INTPNT_CO_TOL_PFEAS", "MSK_DPAR_INTPNT_CO_TOL_DFEAS")
            set_optimizer_attribute(model, key, tolerance)
        end
    else
        throw(ArgumentError("solver must be clarabel or mosek"))
    end
    verbose ? unset_silent(model) : set_silent(model)
    return model
end

"Chordal extension obtained by elimination, followed by maximal-clique extraction."
function composition_cliques(instance)
    m=2instance.N
    adjacency=[Set{Int}() for _ in 1:m]
    for Tn in instance.T
        active=findall(j -> any(!iszero,Tn[:,j]),1:m)
        for i in active,j in active
            i!=j && push!(adjacency[i],j)
        end
    end
    remaining=trues(m)
    candidates=Vector{Int}[]
    # Current coordinates have three voltage neighbors. Eliminating currents
    # first, then voltages around the ring, gives cliques of order at most five.
    order=vcat(collect(1:2:m),collect(2:2:m))
    for v in order
        neighbors=sort!([j for j in adjacency[v] if remaining[j]])
        push!(candidates,sort!(vcat(v,neighbors)))
        for i in neighbors,j in neighbors
            i!=j && push!(adjacency[i],j)
        end
        remaining[v]=false
    end
    cliques=[C for (i,C) in enumerate(candidates) if !any(
        j!=i && length(D)>length(C) && all(v -> v in D,C)
        for (j,D) in enumerate(candidates))]
    return (; cliques,order)
end

function chordal_composition_constraint!(model,aggregate,instance)
    decomposition=composition_cliques(instance)
    cliques=decomposition.cliques
    sums=Dict{Tuple{Int,Int},AffExpr}()
    blocks=Any[]
    for (c,C) in enumerate(cliques)
        k=length(C)
        Z=@variable(model,[1:k,1:k],PSD,base_name="composition_clique_$(c)")
        push!(blocks,Z)
        for j in 1:k,i in 1:j
            key=(C[i],C[j])
            add_to_expression!(get!(sums,key,AffExpr(0.0)),Z[i,j])
        end
    end
    m=size(aggregate,1)
    for j in 1:m,i in 1:j
        !iszero(aggregate[i,j]) && @assert haskey(sums,(i,j))
    end
    # Sparse-PSD decomposition: -Gamma_bar = sum E_C' Z_C E_C.
    # Every extension entry is matched, including fill entries whose target is
    # ZERO. This is an equivalent chordal lifting, not a completion relaxation
    # or a sufficient test using only principal submatrices.
    for ((i,j),expression) in sort!(collect(sums);by=first)
        @constraint(model,expression == -aggregate[i,j])
    end
    return (; cliques,blocks,matching_entries=length(sums),order=decomposition.order)
end

function build_compositional(instance, solver; global_chordal=false, solver_chordal=true, verbose=false)
    N, m = instance.N, 2instance.N
    model = make_model(solver;solver_chordal,verbose)
    P, Gamma, K = Any[], Any[], Any[]
    E = Float64[0 1 0; 0 0 1]
    aggregate = [AffExpr(0.0) for _ in 1:m, _ in 1:m]
    for n in 1:N
        Pn = @variable(model, [1:2, 1:2], PSD, base_name="P_$(n)")
        Gn = @variable(model, [1:3, 1:3], Symmetric, base_name="Gamma_$(n)")
        Fn, Tn = Float64.(instance.F[n]), Float64.(instance.T[n])
        Kn = Gn - Fn' * Pn * Fn + E' * Pn * E - Float64(instance.lambda) * E' * E
        @constraint(model, Symmetric(Kn) in PSDCone())
        # Each local signal depends on only a few global coordinates. Assemble
        # exactly the same global LMI without constructing N dense pullbacks.
        active = findall(j -> any(!iszero, Tn[:,j]), 1:m)
        pullback = Tn[:,active]' * Gn * Tn[:,active]
        for (i, gi) in enumerate(active), (j, gj) in enumerate(active)
            add_to_expression!(aggregate[gi,gj], pullback[i,j])
        end
        push!(P, Pn); push!(Gamma, Gn); push!(K, Kn)
    end
    decomposition=if global_chordal
        chordal_composition_constraint!(model,aggregate,instance)
    else
        @constraint(model, Symmetric(-aggregate) in PSDCone())
        nothing
    end
    @constraint(model, sum(Pn[1, 1] + Pn[2, 2] for Pn in P) == m)
    @objective(model, Min, 0.0) # Cold feasibility search; no certificate warm start.
    global_sizes=global_chordal ? length.(decomposition.cliques) : [m]
    return model, (; P, Gamma, K, aggregate,decomposition,
                     psd_sizes=vcat(fill(2,N),fill(3,N),global_sizes))
end

function build_monolithic(instance, solver;global_chordal=false,solver_chordal=true,verbose=false)
    m = 2instance.N
    model = make_model(solver;solver_chordal,verbose)
    P = @variable(model, [1:m, 1:m], PSD, base_name="P_monolithic")
    A = sparse(Float64.(instance.A))
    K = P - A' * P * A - Float64(instance.lambda) * Matrix{Float64}(I, m, m)
    decomposition=if global_chordal
        # P is unrestricted symmetric: every upper-triangular entry of K has
        # nonzero affine dependence on P. The exact sparsity graph is complete,
        # so chordal preprocessing has ONE full clique. Do not apply the plant's
        # ring cliques to K: that would change the monolithic certificate class.
        @assert all(!iszero(K[i,j]) for j in 1:m for i in 1:j)
        Z=@variable(model,[1:m,1:m],PSD,base_name="monolithic_full_clique")
        for j in 1:m,i in 1:j
            @constraint(model,Z[i,j]==K[i,j])
        end
        (; cliques=[collect(1:m)],blocks=Any[Z],matching_entries=m*(m+1)÷2,order=collect(1:m))
    else
        @constraint(model, Symmetric(K) in PSDCone())
        nothing
    end
    @constraint(model, sum(P[i, i] for i in 1:m) == m)
    @objective(model, Min, 0.0)
    return model, (; P, K,decomposition,psd_sizes=[m,m])
end

"Exact PSD test by unpivoted rational LDL', including the zero-pivot case."
function exact_psd(A::Matrix{Exact})
    A == A' || return (; pass=false, reason="not exactly symmetric", pivots=Exact[])
    n = size(A, 1)
    L = Matrix{Exact}(I, n, n)
    pivots = Exact[]
    for k in 1:n
        d = A[k, k] - sum((L[k, j]^2 * pivots[j] for j in 1:k-1); init=rat(0))
        push!(pivots, d)
        d < 0 && return (; pass=false, reason="negative rational pivot $(k)", pivots)
        for i in k+1:n
            residual = A[i, k] - sum((L[i, j] * L[k, j] * pivots[j]
                                       for j in 1:k-1); init=rat(0))
            if iszero(d)
                iszero(residual) || return (; pass=false,
                    reason="nonzero column at zero pivot $(k)", pivots)
            else
                L[i, k] = residual / d
            end
        end
    end
    return (; pass=true, reason="exact rational LDL PSD", pivots)
end

function matrix_check(name, A)
    # Exact symmetric diagonal dominance is a sufficient PSD certificate.
    # Failure of this inexpensive check is inconclusive: fall back to LDL'.
    symmetric = A == A'
    bound = symmetric ? minimum(A[i,i] - sum((abs(A[i,j]) for j in axes(A,2)
                                    if j != i); init=rat(0)) for i in axes(A,1)) : rat(-1)
    result = symmetric && bound >= 0 ?
        (; pass=true, reason="exact rational diagonal dominance", pivots=Exact[]) : exact_psd(A)
    return (; name, pass=result.pass, reason=result.reason,
             minimum_eigenvalue=eigmin(Symmetric(Float64.(A))),
             exact_diagonal_dominance_bound=fraction(bound),
             minimum_exact_pivot=isempty(result.pivots) ? "none" : fraction(minimum(result.pivots)))
end

function verify_compositional(instance, solution)
    N, m = instance.N, 2instance.N
    E = Exact[0 1 0; 0 0 1]
    P = exact_matrix.(solution.P)
    Gamma = exact_matrix.(solution.Gamma)
    aggregate = zeros(Exact, m, m)
    checks = NamedTuple[]
    grammar_residual = 0.0
    for n in 1:N
        Fn, Tn = instance.F[n], instance.T[n]
        # Reconstruct the Gram matrix from the ACTUAL full-precision P/Gamma
        # and the exact rational model; do not assume a solver identity is exact.
        K = Gamma[n] - Fn' * P[n] * Fn + E' * P[n] * E - instance.lambda * E' * E
        push!(checks, matrix_check("P_$(n)", P[n]))
        push!(checks, matrix_check("local_bad_SOS_$(n)", K))
        push!(checks, matrix_check("local_good_SOS_$(n)", K + instance.lambda * E' * E))
        grammar_residual = max(grammar_residual, maximum(abs.(Float64.(K) - solution.K[n])))
        active = findall(j -> any(!iszero, Tn[:,j]), 1:m)
        aggregate[active,active] += Tn[:,active]' * Gamma[n] * Tn[:,active]
    end
    push!(checks, matrix_check("negative_aggregate_Gamma", -aggregate))
    @assert instance.lambda * instance.radius^2 == instance.epsilon_local
    # Exact identities:
    # G - Delta(z'Pz)       = s'K*s + lambda*||z||^2 >= 0 everywhere.
    # G - Delta(z'Pz) - eps = s'K*s + lambda*(||z||^2-r^2) >= 0 on b_n.
    # These two implications cover ALL six (q,label,q+) projected transitions.
    return (; pass=all(c.pass for c in checks), checks, grammar_residual,
             P, Gamma, aggregate, minimum_aggregate_margin=eigmin(Symmetric(-Float64.(aggregate))))
end

function verify_monolithic(instance, solution)
    m = 2instance.N
    P, A = exact_matrix(solution.P), sparse(instance.A)
    K = P - A' * P * A - instance.lambda * Matrix{Exact}(I, m, m)
    checks = [matrix_check("P_monolithic", P), matrix_check("monolithic_bad_SOS", K)]
    # On global bad, EVERY module satisfies ||z_n||^2 >= r^2:
    # z'(P-A'PA)z-N*eps = z'Kz + lambda*sum_n(||z_n||^2-r^2).
    # On global good (a union of disks) P-A'PA is PSD globally.
    @assert instance.lambda * instance.N * instance.radius^2 ==
            instance.N * instance.epsilon_local
    return (; pass=all(c.pass for c in checks), checks, P,
             grammar_residual=maximum(abs.(Float64.(K) - solution.K)))
end

function solve_candidate(instance, solver, method::Symbol)
    build_seconds = @elapsed model, data = method == :compositional ?
        build_compositional(instance, solver) : build_monolithic(instance, solver)
    solve_seconds = @elapsed optimize!(model)
    status = termination_status(model)
    has_values(model) || error("$(method) returned $(status) without a solution")
    status in (MOI.OPTIMAL, MOI.ALMOST_OPTIMAL) || error("$(method) returned $(status)")
    solution = if method == :compositional
        (; P=[value.(P) for P in data.P], Gamma=[value.(G) for G in data.Gamma],
           K=[value.(K) for K in data.K])
    else
        (; P=value.(data.P), K=value.(data.K))
    end
    feasibility = primal_feasibility_report(model)
    conic_violation = isempty(feasibility) ? 0.0 : maximum(values(feasibility))
    return (; method, solver, status=string(status), build_seconds, solve_seconds,
             solver_version=MOI.get(backend(model), MOI.SolverVersion()),
             conic_violation, solution,
             variables=num_variables(model), psd_sizes=data.psd_sizes,
             psd_entries=sum(s * (s+1) ÷ 2 for s in data.psd_sizes))
end

function verify_candidate(instance, candidate)
    verification_seconds = @elapsed exact = candidate.method == :compositional ?
        verify_compositional(instance, candidate.solution) :
        verify_monolithic(instance, candidate.solution)
    return merge(candidate, (; verification_seconds, exact))
end

solve_formulation(instance, solver, method::Symbol) =
    verify_candidate(instance, solve_candidate(instance, solver, method))

function sample_and_simulate(instance, comp, mono; samples=5000)
    rng = MersenneTwister(instance.seed + 1)
    A = Float64.(instance.A)
    P, Gamma = comp.solution.P, comp.solution.Gamma
    eps = Float64(instance.epsilon_local)
    minimum_local = Inf
    minimum_composed, minimum_monolithic = Inf, Inf
    supply_identity_error = 0.0
    rank(P, z, q, offset) = dot(z, P*z) + (q == :bad ? offset : 0.0)
    for trial in 0:samples
        for n in 1:instance.N
            z = trial == 0 ? zeros(2) : 2rand(rng, 2) .- 1
            w = trial == 0 ? 0.0 : 2rand(rng)-1
            s = [w; z]
            zp = Float64.(instance.F[n]) * s
            G = dot(s, Gamma[n]*s)
            for q in (:bad, :good), qp in local_successors(available(instance, z))
                residual = G + rank(P[n], z, q, eps) - rank(P[n], zp, qp, eps) -
                           (q == :bad ? eps : 0.0)
                minimum_local = min(minimum_local, residual)
            end
        end
        z = trial == 0 ? zeros(2instance.N) : 2rand(rng, 2instance.N) .- 1
        zp = A * z
        qp = global_successor(instance, z)
        Gsum = sum(begin s=Float64.(instance.T[n])*z; dot(s,Gamma[n]*s) end
                   for n in 1:instance.N)
        supply_identity_error = max(supply_identity_error,
            abs(Gsum - dot(z, Float64.(comp.exact.aggregate)*z)))
        for q in (:bad, :good)
            V = sum(rank(P[n], z[2n-1:2n], q, eps) for n in 1:instance.N)
            Vp = sum(rank(P[n], zp[2n-1:2n], qp, eps) for n in 1:instance.N)
            decrement = q == :bad ? instance.N * eps : 0.0
            minimum_composed = min(minimum_composed, V - Vp - decrement)
            minimum_monolithic = min(minimum_monolithic,
                rank(mono.solution.P,z,q,instance.N*eps) -
                rank(mono.solution.P,zp,qp,instance.N*eps) - decrement)
        end
    end
    entry = validate_instance(instance).guaranteed_available_step
    horizon = max(entry + 10, 100)
    maximum_entry = 0
    for trajectory in 1:30
        z = Float64.(instance.initial_lower) + rand(rng, 2instance.N) .*
            Float64.(instance.initial_upper - instance.initial_lower)
        q = :bad
        first_good = nothing
        for t in 0:horizon
            qp = global_successor(instance, z) # Current label, NOT successor label.
            if qp == :good && isnothing(first_good)
                first_good = t
            end
            for n in 1:instance.N
                @assert qp in local_successors(available(instance, z[2n-1:2n]))
                @assert -1-1e-12 <= minimum(z[2n-1:2n])
                @assert maximum(z[2n-1:2n]) <= 1+1e-12
                @assert 0 <= physical_controller(instance,n,z[2n-1:2n]) <= 1
            end
            t >= entry && @assert qp == :good
            q, z = qp, A*z
        end
        isnothing(first_good) && error("trajectory did not reach availability")
        maximum_entry = max(maximum_entry, first_good)
    end
    @testset "Returned certificates and shared-state trajectories" begin
        @test comp.exact.pass
        @test mono.exact.pass
        @test minimum_local >= -1e-8
        @test minimum_composed >= -1e-8
        @test minimum_monolithic >= -1e-8
        @test supply_identity_error <= 1e-10
        @test maximum_entry <= entry
    end
    @testset "Verifier rejects invalid matrices and broken composition" begin
        @test exact_psd(Exact[1 0; 0 0]).pass
        @test !exact_psd(Exact[1 0; 0 -1]).pass
        @test !exact_psd(Exact[0 1; 1 0]).pass
        altered_Gamma = deepcopy(comp.solution.Gamma)
        altered_Gamma[1] += 100Matrix{Float64}(I,3,3)
        altered_solution = (; comp.solution.P, Gamma=altered_Gamma, comp.solution.K)
        altered = verify_compositional(instance,altered_solution)
        @test all(c.pass for c in altered.checks[1:end-1])
        @test !last(altered.checks).pass
        @test !altered.pass
        @test !verify_monolithic(instance,(; P=-mono.solution.P,K=mono.solution.K)).pass
    end
    return (; samples, minimum_local, minimum_composed, minimum_monolithic,
             supply_identity_error, trajectories=30, horizon, maximum_entry)
end

function result_dictionary(result)
    d = Dict{String,Any}(
        "method"=>string(result.method), "solver"=>string(result.solver),
        "solver_version"=>result.solver_version,
        "status"=>result.status, "exact_certificate_pass"=>result.exact.pass,
        "build_seconds"=>result.build_seconds, "solve_seconds"=>result.solve_seconds,
        "verification_seconds"=>result.verification_seconds,
        "maximum_conic_violation"=>result.conic_violation,
        "variables"=>result.variables, "psd_block_sizes"=>result.psd_sizes,
        "independent_psd_entries"=>result.psd_entries,
        "solver_Gram_identity_residual"=>result.exact.grammar_residual,
        "exact_matrix_checks"=>[Dict(string(k)=>v for (k,v) in pairs(c))
                                 for c in result.exact.checks])
    if result.method == :compositional
        d["P"] = [rows(P) for P in result.solution.P]
        d["Gamma"] = [rows(G) for G in result.solution.Gamma]
        d["SOS_Gram"] = [rows(K) for K in result.solution.K]
        d["aggregate_Gamma"] = rows(Float64.(result.exact.aggregate))
        d["aggregate_margin"] = result.exact.minimum_aggregate_margin
    else
        d["P"] = rows(result.solution.P)
        d["SOS_Gram"] = rows(result.solution.K)
    end
    return d
end

function save_results(instance, bounds, comp, mono, validation)
    stamp = Dates.format(now(UTC), "yyyymmddTHHMMSSsss")
    directory = joinpath(@__DIR__, "Results",
                         "N$(instance.N)_seed$(instance.seed)_$(comp.solver)_$(stamp)Z")
    mkpath(directory)
    parameters = [Dict(string(k)=>v isa Exact ? fraction(v) : v for (k,v) in pairs(p))
                  for p in instance.modules]
    data = Dict{String,Any}(
        "N"=>instance.N, "state_dimension"=>2instance.N, "seed"=>instance.seed,
        "julia_version"=>string(VERSION), "conda_environment"=>get(ENV,"CONDA_DEFAULT_ENV",""),
        "JuMP_version"=>string(pkgversion(JuMP)),
        "Clarabel_version"=>string(pkgversion(Clarabel)),
        "MosekTools_version"=>string(pkgversion(MosekTools)),
        "certificate_degree"=>2, "SOS_residual_degree"=>2, "SOS_order"=>1,
        "solver_feasibility_tolerance"=>1.0e-9, "solver_time_limit_seconds"=>120.0,
        "BLAS_threads"=>BLAS.get_num_threads(),
        "controller_search"=>false, "barrier"=>"zero, with independently proved domain invariance",
        "specification"=>"F G (a_1 OR ... OR a_N)", "shared_global_automaton"=>true,
        "coefficient_encoding"=>"TOML binary64 round-trip; verifier reconstructs exact binary rationals",
        "dt_seconds"=>fraction(instance.dt), "radius"=>fraction(instance.radius),
        "alpha"=>fraction(instance.alpha),
        "local_normalized_state_box"=>[[-1.0,1.0],[-1.0,1.0]],
        "local_internal_input_interval"=>[-1.0,1.0],
        "physical_duty_ratio_interval"=>[0.0,1.0],
        "initial_lower_exact"=>fraction.(instance.initial_lower),
        "initial_upper_exact"=>fraction.(instance.initial_upper),
        "shared_priority_bad"=>1, "shared_priority_good"=>2,
        "epsilon_local"=>fraction(instance.epsilon_local),
        "epsilon_global"=>fraction(instance.N * instance.epsilon_local),
        "constant_SOS_multiplier"=>fraction(instance.lambda),
        "current_scale_amps"=>fraction(instance.current_scale),
        "voltage_scale_volts"=>fraction(instance.voltage_scale),
        "voltage_reference_volts"=>fraction(instance.voltage_reference),
        "module_parameters_exact"=>parameters,
        "conductance_exact"=>rows(fraction.(instance.conductance)),
        "M_exact"=>rows(fraction.(instance.M)), "A_exact"=>rows(fraction.(instance.A)),
        "contraction_bound"=>fraction(bounds.rho),
        "guaranteed_availability_state_step"=>bounds.guaranteed_available_step,
        "guaranteed_even_automaton_step"=>bounds.guaranteed_good_automaton_step,
        "compositional"=>result_dictionary(comp), "monolithic"=>result_dictionary(mono),
        "sampling"=>Dict(string(k)=>v for (k,v) in pairs(validation)))
    path = joinpath(directory, "results.toml")
    open(path, "w") do io
        TOML.print(io, data; sorted=true)
    end
    @assert TOML.parsefile(path)["compositional"]["P"] == data["compositional"]["P"]
    return path
end

matrix_from_rows(data) = permutedims(hcat((Float64.(row) for row in data)...))

"Independently reload exported binary64 coefficients and recheck exact SOS/LMI identities."
function verify_saved_results(path::String)
    data = TOML.parsefile(path)
    instance = generate_instance(data["N"], data["seed"])
    @assert data["A_exact"] == rows(fraction.(instance.A))
    @assert data["M_exact"] == rows(fraction.(instance.M))
    @assert data["epsilon_local"] == fraction(instance.epsilon_local)
    @assert data["constant_SOS_multiplier"] == fraction(instance.lambda)
    @assert data["initial_lower_exact"] == fraction.(instance.initial_lower)
    @assert data["initial_upper_exact"] == fraction.(instance.initial_upper)
    c, m = data["compositional"], data["monolithic"]
    comp_solution = (; P=matrix_from_rows.(c["P"]), Gamma=matrix_from_rows.(c["Gamma"]),
                       K=matrix_from_rows.(c["SOS_Gram"]))
    mono_solution = (; P=matrix_from_rows(m["P"]), K=matrix_from_rows(m["SOS_Gram"]))
    comp = verify_compositional(instance,comp_solution)
    mono = verify_monolithic(instance,mono_solution)
    @testset "Exported full-precision certificate reload" begin
        @test comp.pass
        @test mono.pass
        @test comp.grammar_residual <= 1e-10
        @test mono.grammar_residual <= 1e-10
    end
    println("Saved compositional and monolithic coefficients: exact SOS/aggregate checks PASS")
    return (; pass=comp.pass && mono.pass, comp, mono)
end

function main(args=ARGS)
    get(ENV,"CONDA_DEFAULT_ENV","") == "optimization" ||
        error("Run Julia through conda run -n optimization")
    if !isempty(args) && args[1] == "verify"
        length(args) == 2 || throw(ArgumentError("verify requires a results.toml path"))
        return verify_saved_results(args[2])
    end
    N = length(args)>=1 ? parse(Int,args[1]) : 2
    solver = length(args)>=2 ? Symbol(lowercase(args[2])) : :mosek
    seed = length(args)>=3 ? parse(Int,args[3]) : 20261122
    samples = length(args)>=4 ? parse(Int,args[4]) : 5000
    samples >= 1 || throw(ArgumentError("samples must be positive"))
    BLAS.set_num_threads(1)
    instance = generate_instance(N, seed)
    println("Buck-converter CPC pilot: N=$(N), m=$(2N), solver=$(solver), seed=$(seed)")
    println("Degree 2; SOS order 1; alpha=0.01; supplied affine feedback; one shared global DPA")
    bounds = validate_instance(instance)
    println("Exact robust domain/control checks: PASS; contraction bound=",Float64(bounds.rho))
    println("Guaranteed persistent availability by state step ",bounds.guaranteed_available_step)
    # A separate unreported instance warms BOTH builders and solver paths.
    warm = generate_instance(2, seed + 10_000)
    for method in (:compositional, :monolithic)
        result = solve_formulation(warm, solver, method)
        result.exact.pass || error("$(method) warm-up exact verification failed")
    end
    comp = solve_formulation(instance, solver, :compositional)
    mono = solve_formulation(instance, solver, :monolithic)
    for result in (comp,mono)
        @printf("%-14s build %.6f s | solve %.6f s | exact check %.6f s | %s\n",
                string(result.method),result.build_seconds,result.solve_seconds,
                result.verification_seconds,result.status)
        println("  exact certificate: ",result.exact.pass,
                "; variables=",result.variables,"; PSD sizes=",result.psd_sizes)
        for c in result.exact.checks
            @printf("  %-27s exact=%s, lambda_min=%.6e\n",c.name,string(c.pass),c.minimum_eigenvalue)
        end
    end
    validation = sample_and_simulate(instance,comp,mono; samples)
    path = save_results(instance,bounds,comp,mono,validation)
    verify_saved_results(path)
    println("All model, projection, SOS, composition and trajectory checks: PASS")
    println("Results: ",path)
    println("A single-instance feasibility run does not establish a scaling advantage.")
    return (; instance, bounds, comp, mono, validation, path)
end

end # module

if abspath(PROGRAM_FILE) == abspath(@__FILE__)
    BuckConverterCPC.main()
end
